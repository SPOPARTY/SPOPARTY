INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (157,'2024-02-07 22:58:02.673157','2024-02-10 22:17:58.909956','https://media.api-sports.io/football/teams/157.png','Bayern Munich','Bayern Munich'),
	 (160,'2024-02-07 22:58:03.252654','2024-02-10 22:17:59.356220','https://media.api-sports.io/football/teams/160.png','SC Freiburg','SC Freiburg'),
	 (161,'2024-02-07 22:58:03.773693','2024-02-10 22:17:59.809336','https://media.api-sports.io/football/teams/161.png','VfL Wolfsburg','VfL Wolfsburg'),
	 (162,'2024-02-07 22:58:04.282928','2024-02-10 22:18:00.369019','https://media.api-sports.io/football/teams/162.png','Werder Bremen','Werder Bremen'),
	 (163,'2024-02-07 22:58:04.825763','2024-02-10 22:18:00.814628','https://media.api-sports.io/football/teams/163.png','Borussia Monchengladbach','Borussia Monchengladbach'),
	 (164,'2024-02-07 22:58:05.345223','2024-02-10 22:18:01.360765','https://media.api-sports.io/football/teams/164.png','FSV Mainz 05','FSV Mainz 05'),
	 (165,'2024-02-07 22:58:05.865320','2024-02-10 22:18:01.815353','https://media.api-sports.io/football/teams/165.png','Borussia Dortmund','Borussia Dortmund'),
	 (167,'2024-02-07 22:58:06.389791','2024-02-10 22:18:02.277276','https://media.api-sports.io/football/teams/167.png','1899 Hoffenheim','1899 Hoffenheim'),
	 (168,'2024-02-07 22:58:06.901480','2024-02-10 22:18:02.737183','https://media.api-sports.io/football/teams/168.png','Bayer Leverkusen','Bayer Leverkusen'),
	 (169,'2024-02-07 22:58:07.416421','2024-02-10 22:18:03.324847','https://media.api-sports.io/football/teams/169.png','Eintracht Frankfurt','Eintracht Frankfurt');
INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (170,'2024-02-07 22:58:07.936528','2024-02-10 22:18:03.767228','https://media.api-sports.io/football/teams/170.png','FC Augsburg','FC Augsburg'),
	 (172,'2024-02-07 22:58:08.452322','2024-02-10 22:18:04.212165','https://media.api-sports.io/football/teams/172.png','VfB Stuttgart','VfB Stuttgart'),
	 (173,'2024-02-07 22:58:08.972440','2024-02-10 22:18:04.668947','https://media.api-sports.io/football/teams/173.png','RB Leipzig','RB Leipzig'),
	 (176,'2024-02-07 22:58:09.485350','2024-02-10 22:18:05.115618','https://media.api-sports.io/football/teams/176.png','Vfl Bochum','Vfl Bochum'),
	 (180,'2024-02-07 22:58:09.999675','2024-02-10 22:18:05.562931','https://media.api-sports.io/football/teams/180.png','FC Heidenheim','FC Heidenheim'),
	 (181,'2024-02-07 22:58:10.510370','2024-02-10 22:18:06.010472','https://media.api-sports.io/football/teams/181.png','SV Darmstadt 98','SV Darmstadt 98'),
	 (182,'2024-02-07 22:58:11.022193','2024-02-10 22:18:06.449429','https://media.api-sports.io/football/teams/182.png','Union Berlin','Union Berlin'),
	 (192,'2024-02-07 22:58:11.521910','2024-02-10 22:18:06.883076','https://media.api-sports.io/football/teams/192.png','1.FC Köln','1.FC Köln'),
	 (529,'2024-02-07 22:57:50.971753','2024-02-10 22:17:47.776917','https://media.api-sports.io/football/teams/529.png','Barcelona','Barcelona'),
	 (530,'2024-02-07 22:57:51.661265','2024-02-10 22:17:48.252312','https://media.api-sports.io/football/teams/530.png','Atletico Madrid','Atletico Madrid');
INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (531,'2024-02-07 22:57:52.193001','2024-02-10 22:17:48.700882','https://media.api-sports.io/football/teams/531.png','Athletic Club','Athletic Club'),
	 (532,'2024-02-07 22:57:52.716031','2024-02-10 22:17:49.153704','https://media.api-sports.io/football/teams/532.png','Valencia','Valencia'),
	 (533,'2024-02-07 22:57:53.254676','2024-02-10 22:17:49.614893','https://media.api-sports.io/football/teams/533.png','Villarreal','Villarreal'),
	 (534,'2024-02-07 22:57:53.960424','2024-02-10 22:17:50.069705','https://media.api-sports.io/football/teams/534.png','Las Palmas','Las Palmas'),
	 (536,'2024-02-07 22:57:54.516597','2024-02-10 22:17:50.527269','https://media.api-sports.io/football/teams/536.png','Sevilla','Sevilla'),
	 (538,'2024-02-07 22:57:55.036434','2024-02-10 22:17:51.063705','https://media.api-sports.io/football/teams/538.png','Celta Vigo','Celta Vigo'),
	 (541,'2024-02-07 22:57:55.576094','2024-02-10 22:17:51.516004','https://media.api-sports.io/football/teams/541.png','Real Madrid','Real Madrid'),
	 (542,'2024-02-07 22:57:56.105423','2024-02-10 22:17:51.984627','https://media.api-sports.io/football/teams/542.png','Alaves','Alaves'),
	 (543,'2024-02-07 22:57:56.722437','2024-02-10 22:17:52.424155','https://media.api-sports.io/football/teams/543.png','Real Betis','Real Betis'),
	 (546,'2024-02-07 22:57:57.251583','2024-02-10 22:17:52.866611','https://media.api-sports.io/football/teams/546.png','Getafe','Getafe');
INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (547,'2024-02-07 22:57:57.768446','2024-02-10 22:17:53.314191','https://media.api-sports.io/football/teams/547.png','Girona','Girona'),
	 (548,'2024-02-07 22:57:58.296878','2024-02-10 22:17:53.756841','https://media.api-sports.io/football/teams/548.png','Real Sociedad','Real Sociedad'),
	 (715,'2024-02-07 22:57:58.827994','2024-02-10 22:17:54.204519','https://media.api-sports.io/football/teams/715.png','Granada CF','Granada CF'),
	 (723,'2024-02-07 22:57:59.351002','2024-02-10 22:17:54.647078','https://media.api-sports.io/football/teams/723.png','Almeria','Almeria'),
	 (724,'2024-02-07 22:57:59.878150','2024-02-10 22:17:55.118570','https://media.api-sports.io/football/teams/724.png','Cadiz','Cadiz'),
	 (727,'2024-02-07 22:58:00.652008','2024-02-10 22:17:55.724876','https://media.api-sports.io/football/teams/727.png','Osasuna','Osasuna'),
	 (728,'2024-02-07 22:58:01.176371','2024-02-10 22:17:56.350366','https://media.api-sports.io/football/teams/728.png','Rayo Vallecano','Rayo Vallecano'),
	 (798,'2024-02-07 22:58:01.845333','2024-02-10 22:17:57.847677','https://media.api-sports.io/football/teams/798.png','Mallorca','Mallorca'),
	 (2746,'2024-02-07 22:58:12.377163','2024-02-10 22:18:07.632613','https://media.api-sports.io/football/teams/2746.png','Gangwon FC','Gangwon FC'),
	 (2747,'2024-02-07 22:58:12.942665','2024-02-10 22:18:08.090119','https://media.api-sports.io/football/teams/2747.png','Daegu FC','Daegu FC');
INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (2750,'2024-02-07 22:58:13.455520','2024-02-10 22:18:08.565529','https://media.api-sports.io/football/teams/2750.png','Daejeon Citizen','Daejeon Citizen'),
	 (2752,'2024-02-07 22:58:13.974816','2024-02-10 22:18:09.013092','https://media.api-sports.io/football/teams/2752.png','Busan I Park','Busan I Park'),
	 (2756,'2024-02-07 22:58:14.471457','2024-02-10 22:18:09.451771','https://media.api-sports.io/football/teams/2756.png','Suwon City FC','Suwon City FC'),
	 (2759,'2024-02-07 22:58:14.986140','2024-02-10 22:18:09.899754','https://media.api-sports.io/football/teams/2759.png','Gwangju FC','Gwangju FC'),
	 (2761,'2024-02-07 22:58:15.519791','2024-02-10 22:18:10.338342','https://media.api-sports.io/football/teams/2761.png','Jeju United FC','Jeju United FC'),
	 (2762,'2024-02-07 22:58:16.033898','2024-02-10 22:18:10.820803','https://media.api-sports.io/football/teams/2762.png','Jeonbuk Motors','Jeonbuk Motors'),
	 (2763,'2024-02-07 22:58:16.564287','2024-02-10 22:18:11.262787','https://media.api-sports.io/football/teams/2763.png','Incheon United','Incheon United'),
	 (2764,'2024-02-07 22:58:17.518782','2024-02-10 22:18:11.711963','https://media.api-sports.io/football/teams/2764.png','Pohang Steelers','Pohang Steelers'),
	 (2765,'2024-02-07 22:58:18.020443','2024-02-10 22:18:12.159494','https://media.api-sports.io/football/teams/2765.png','Suwon Bluewings','Suwon Bluewings'),
	 (2766,'2024-02-07 22:58:18.534861','2024-02-10 22:18:12.599339','https://media.api-sports.io/football/teams/2766.png','FC Seoul','FC Seoul');
INSERT INTO s10p12a802.team (team_id,created_time,updated_time,logo,name_eng,name_kr) VALUES
	 (2767,'2024-02-07 22:58:19.052578','2024-02-10 22:18:13.045834','https://media.api-sports.io/football/teams/2767.png','Ulsan Hyundai FC','Ulsan Hyundai FC'),
	 (7078,'2024-02-07 22:58:19.527869','2024-02-10 22:18:13.443484','https://media.api-sports.io/football/teams/7078.png','Gimpo Citizen','Gimpo Citizen');
