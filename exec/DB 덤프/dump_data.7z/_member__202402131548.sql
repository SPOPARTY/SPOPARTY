INSERT INTO s10p12a802.`member` (created_time,updated_time,email,login_id,login_pwd,nickname,provider,role_name,state,team_id) VALUES
	 ('2024-02-07 05:30:52.000000','2024-02-10 14:42:05.350895','kbumk1234@naver.com','gyfl5542','1','횰','basic','ROLE.USER',0,164),
	 ('2024-02-09 16:07:28.950395','2024-02-13 12:39:19.485232','kbumk1234@naver.com','kbumk123','$2y$04$Fz2ywTAdSH6jyEv27d8jGuJ10q/k2V889cArY9cPwzt6fgrMPc/zG','김종범','basic','ROLE_USER',0,168),
	 ('2024-02-09 16:08:09.091129','2024-02-10 18:05:14.495797','jsh09865@gmail.com','jsh09865','$2a$10$4gc4dP018nn7zrE/iERa8.ViTO/sc0SsaLnqUPYI9CEGFWpGVN0sm','jsh09865','basic','ROLE_USER',2,157),
	 ('2024-02-09 16:08:51.134570','2024-02-11 14:09:50.650395','kbumk1234@nate.com','kakao_3301208000','$2a$10$04MnCcHejx7yKhROnnqMnuhrhzpPAU21zUkepdSHgUtGGA2zXSiZy','김종범','kakao','ROLE_USER',0,529),
	 ('2024-02-09 16:20:02.051252','2024-02-13 13:50:37.968920','gogoadl@naver.com','kakao_3325377426','$2a$10$Tn1k1PWfuI6POSnDfKdKJu0lJ3vCwBMhj0yBPSIvwc7GUQrGIJTI2','박현우','kakao','ROLE_USER',0,2747),
	 ('2024-02-09 16:23:05.674492','2024-02-10 02:24:50.212041','joeunbyeol98@gmail.com','sksmsdmsquf','$2a$10$tto5VQAAJ85o4vsC1tlRK.4GWcazst9X1xUXg0EqgVi0hIVVAOhDa','나는은별','basic','ROLE_USER',0,2762),
	 ('2024-02-10 02:00:57.747756','2024-02-10 02:00:57.747756','rlawldbs42@gmail.com','FETEST','$2a$10$vV80orEZj.30c3vwMLjxHO/24J.emmhCiNH1nWj638zwK6YK7TEAi','fetest','basic','ROLE_USER',0,2762),
	 ('2024-02-10 02:03:43.516046','2024-02-10 02:03:43.516046','haka0119@kakao.com','kakao_3334057303','$2a$10$TMuxL7x4hnom40/P8yydxO14mrhxPEHRayf6H223bMhZ/cmTIjFXO','황인규','kakao','ROLE_USER',0,2762),
	 ('2024-02-10 02:20:32.759227','2024-02-13 12:01:42.056639','a01077517236@gmail.com','gogoadl','$2a$10$VrR2DWbj2VHC4Cg6BxtIBeH6QxzRar.ImrUWIm9G09VVGK.DeARX2','마루세1','basic','ROLE_USER',0,157),
	 ('2024-02-10 13:26:53.310136','2024-02-10 14:37:41.774535','jason9865@naver.com','tesst','$2a$10$Ubz4iEXqA2inrVYWZlqqf.zQ/p3JqSBwCI2yM1CdqGAs7fiQCi1ye','팔카오페이333','basic','ROLE_USER',2,157);
INSERT INTO s10p12a802.`member` (created_time,updated_time,email,login_id,login_pwd,nickname,provider,role_name,state,team_id) VALUES
	 ('2024-02-10 14:38:27.217585','2024-02-10 18:20:10.171040','jason9865@naver.com','test','$2a$10$sdPhY6ZM4wIKNhQbuyHClepSCe8PzkVU7vCwyLgCUcxbntXcdSVnO','test','basic','ROLE_USER',2,157),
	 ('2024-02-10 14:42:32.939759','2024-02-10 14:42:32.939759','ssafy@edu.ssafy.com','shdfds12322','$2a$10$fl1YAMhPFD0DUl0BVIzjve3kYm83jnwo..blXk9lT2aTnKoLD9MkS','김싸피','basic','ROLE_USER',0,NULL),
	 ('2024-02-10 18:13:41.442540','2024-02-11 23:25:23.467126','jsh09865@gmail.com','test1','$2a$10$pU/BzYW7GKXcq.RumJG.JetoDp5ZfA799lM9Qdls0MFxZTtJqNTBi','장승호','basic','ROLE_USER',0,168),
	 ('2024-02-10 18:19:07.950959','2024-02-10 18:19:39.516354','jason9865@hanmail.net','tttttt','$2a$10$mn0JmxC4Kgdu/di.qxJwCek/WW/lPb4RhsiflWknVJqpM.Es8TD1e','ttt','basic','ROLE_USER',2,161),
	 ('2024-02-10 19:33:13.330233','2024-02-10 19:33:13.330233','thdus981005@naver.com','thdus981005','$2a$10$GRbz73tBTAYYou190qP6N.TpNL8SLoclDI6R4zCv3RZAaVKyyhHIi','soyonii','basic','ROLE_USER',0,2761),
	 ('2024-02-11 02:40:59.065625','2024-02-11 03:06:24.623956','chonicestar@naver.com','kakao_3333876038','$2a$10$5Ue2aGj5o8D0tyGETQugYOSbvYuBlGc9IRICct1BRCyIPClAXoIPS','조은별','kakao','ROLE_USER',0,NULL),
	 ('2024-02-11 13:45:31.736851','2024-02-11 13:45:31.736851','jason9865@kakao.com','kakao_3306563149','$2a$10$hHR9HcUN9fTWi1hd2H4bN.iIK2PUpxmGbrcsbxf0EuUoeWRAqcUF.','장승호','kakao','ROLE_USER',0,NULL),
	 ('2024-02-11 14:30:52.212999','2024-02-11 14:30:52.212999','haka0119@naver.com','fetest2','$2a$10$uNZGGJgwD9tGZ3X3KrEdVu53FnFRN.QNi45j1hY/UEyfvcyt8SSW2','FETEST2','basic','ROLE_USER',0,160),
	 ('2024-02-11 21:22:00.275681','2024-02-11 21:22:00.275681','gufl6827@nate.com','kakao_3338443243','$2a$10$FolrVNOR1FEKTQLp.AojOOtzjIU6p7W67BQoEnxYTUT6lCuAPbFda','효리','kakao','ROLE_USER',0,NULL),
	 ('2024-02-12 03:01:58.234849','2024-02-12 03:01:58.234849','mmm3657@kakao.com','kakao_3338753154','$2a$10$fjqk87JVzKmYX8h2dQr5m.9yLYPIkxdpLFru6fDfZU5Gz0zVdeoIi','김강민','kakao','ROLE_USER',0,NULL);
INSERT INTO s10p12a802.`member` (created_time,updated_time,email,login_id,login_pwd,nickname,provider,role_name,state,team_id) VALUES
	 ('2024-02-13 10:19:34.900577','2024-02-13 10:19:34.900577','eharaz@naver.com','test12','$2a$10$VS1tP5gwYC/kDShHbcTaTuA8h5Bhq6O3WdhxDKlQO16L2F25rmshu','test12','basic','ROLE_USER',0,163),
	 ('2024-02-13 14:54:44.651532','2024-02-13 14:54:44.651532','kbumk1234@gmail.com','ssafy','$2y$04$Fz2ywTAdSH6jyEv27d8jGuJ10q/k2V889cArY9cPwzt6fgrMPc/zG','김싸피','basic','ROLE_USER',0,157);
