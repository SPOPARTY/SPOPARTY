CREATE DATABASE `s10p12a802` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin */;




-- s10p12a802.archive definition

CREATE TABLE `archive` (
  `archive_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) DEFAULT NULL,
  `fixture_title` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `party_title` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `club_id` bigint(20) DEFAULT NULL,
  `file_id` bigint(20) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `thumbnail_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`archive_id`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;


-- s10p12a802.board definition

CREATE TABLE `board` (
  `board_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `content` varchar(2000) COLLATE utf8mb4_bin NOT NULL,
  `title` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `club_id` bigint(20) DEFAULT NULL,
  `file_id` bigint(20) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`board_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.cheer definition

CREATE TABLE `cheer` (
  `cheer_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `cheer_fixture_id` bigint(20) NOT NULL,
  `member_id` bigint(20) NOT NULL,
  `season_league_team_id` bigint(20) NOT NULL,
  PRIMARY KEY (`cheer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.cheer_fixture definition

CREATE TABLE `cheer_fixture` (
  `cheer_fixture_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `away_count` bigint(20) NOT NULL,
  `home_count` bigint(20) NOT NULL,
  `fixture_id` bigint(20) NOT NULL,
  PRIMARY KEY (`cheer_fixture_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.choice definition

CREATE TABLE `choice` (
  `choice_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `count` int(11) NOT NULL DEFAULT 0,
  `is_answer` tinyint(4) DEFAULT NULL,
  `vote_id` bigint(20) NOT NULL,
  PRIMARY KEY (`choice_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.club definition

CREATE TABLE `club` (
  `club_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `max_participants` int(11) NOT NULL,
  `name` varchar(30) COLLATE utf8mb4_bin NOT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `party_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`club_id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.club_member definition

CREATE TABLE `club_member` (
  `club_member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `club_id` bigint(20) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`club_member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.coach definition

CREATE TABLE `coach` (
  `coach_id` bigint(20) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `age` int(11) NOT NULL,
  `name_eng` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `name_kr` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `nationality` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `photo` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`coach_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.file definition

CREATE TABLE `file` (
  `file_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) DEFAULT NULL,
  `thumbnail_url` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `url` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`file_id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.fixture definition

CREATE TABLE `fixture` (
  `fixture_id` bigint(20) NOT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `updated_time` datetime(6) DEFAULT NULL,
  `away_team_goal` tinyint(4) DEFAULT NULL,
  `home_team_goal` tinyint(4) DEFAULT NULL,
  `round_eng` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `round_kr` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `start_time` datetime(6) DEFAULT NULL,
  `status` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `away_team_id` bigint(20) DEFAULT NULL,
  `home_team_id` bigint(20) DEFAULT NULL,
  `season_league_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fixture_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.fixture_event definition

CREATE TABLE `fixture_event` (
  `fixture_event_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `detail` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `time` bigint(20) DEFAULT NULL,
  `type` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `assist_id` bigint(20) DEFAULT NULL,
  `fixture_id` bigint(20) DEFAULT NULL,
  `player_id` bigint(20) DEFAULT NULL,
  `season_league_team_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`fixture_event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=973 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.following_team definition

CREATE TABLE `following_team` (
  `following_team_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`following_team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.league definition

CREATE TABLE `league` (
  `league_id` bigint(20) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `country` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `country_logo` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `logo` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `name_eng` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `name_kr` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `type` varchar(10) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`league_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.lineup definition

CREATE TABLE `lineup` (
  `lineup_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `formation` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `fixture_id` bigint(20) DEFAULT NULL,
  `season_league_team_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`lineup_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12201 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.lineup_player definition

CREATE TABLE `lineup_player` (
  `lineup_player_id` bigint(20) NOT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `updated_time` datetime(6) DEFAULT NULL,
  `grid` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `number` varchar(3) COLLATE utf8mb4_bin DEFAULT NULL,
  `position` varchar(20) COLLATE utf8mb4_bin DEFAULT NULL,
  `lineup_id` bigint(20) DEFAULT NULL,
  `name` varchar(50) COLLATE utf8mb4_bin DEFAULT NULL,
  `season_league_team_player_id` bigint(20) DEFAULT NULL,
  `main_player` tinyint(4) NOT NULL,
  PRIMARY KEY (`lineup_player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.`member` definition

CREATE TABLE `member` (
  `member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `email` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `login_id` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `login_pwd` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `nickname` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `provider` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `role_name` varchar(25) COLLATE utf8mb4_bin NOT NULL,
  `state` int(11) NOT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.member_token definition

CREATE TABLE `member_token` (
  `member_token_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `refresh_token` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`member_token_id`)
) ENGINE=InnoDB AUTO_INCREMENT=262 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.notification definition

CREATE TABLE `notification` (
  `notification_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `content` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  `state` int(11) NOT NULL,
  `title` varchar(50) COLLATE utf8mb4_bin NOT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`notification_id`)
) ENGINE=InnoDB AUTO_INCREMENT=453 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.party definition

CREATE TABLE `party` (
  `party_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `fixture_url` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `max_participants` int(11) NOT NULL,
  `openvidu_session_id` varchar(255) COLLATE utf8mb4_bin DEFAULT NULL,
  `title` varchar(30) COLLATE utf8mb4_bin DEFAULT NULL,
  `fixture_id` bigint(20) DEFAULT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`party_id`)
) ENGINE=InnoDB AUTO_INCREMENT=228 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.party_member definition

CREATE TABLE `party_member` (
  `party_member_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `openvidu_token` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `role` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `member_id` bigint(20) DEFAULT NULL,
  `party_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`party_member_id`)
) ENGINE=InnoDB AUTO_INCREMENT=344 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.penalty definition

CREATE TABLE `penalty` (
  `penalty_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `content` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`penalty_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.player definition

CREATE TABLE `player` (
  `player_id` bigint(20) NOT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `updated_time` datetime(6) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `height` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  `name_eng` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `name_kr` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `nationality` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  `photo` varchar(200) COLLATE utf8mb4_bin DEFAULT NULL,
  `weight` varchar(10) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`player_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.season definition

CREATE TABLE `season` (
  `season_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `value` varchar(4) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`season_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2024 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.season_league definition

CREATE TABLE `season_league` (
  `season_league_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `season_end_date` datetime(6) NOT NULL,
  `season_start_date` datetime(6) NOT NULL,
  `league_id` bigint(20) NOT NULL,
  `season_id` bigint(20) NOT NULL,
  PRIMARY KEY (`season_league_id`)
) ENGINE=InnoDB AUTO_INCREMENT=197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.season_league_team definition

CREATE TABLE `season_league_team` (
  `season_league_team_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) DEFAULT NULL,
  `updated_time` datetime(6) DEFAULT NULL,
  `coach_id` bigint(20) DEFAULT NULL,
  `season_league_id` bigint(20) DEFAULT NULL,
  `team_id` bigint(20) DEFAULT NULL,
  PRIMARY KEY (`season_league_team_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4197 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.season_league_team_player definition

CREATE TABLE `season_league_team_player` (
  `created_time` datetime(6) DEFAULT NULL,
  `updated_time` datetime(6) DEFAULT NULL,
  `player_id` bigint(20) DEFAULT NULL,
  `season_league_team_id` bigint(20) DEFAULT NULL,
  `season_league_team_player_id` bigint(20) NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`season_league_team_player_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3293 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.standings definition

CREATE TABLE `standings` (
  `standings_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `draw` int(11) NOT NULL,
  `form` varchar(5) COLLATE utf8mb4_bin NOT NULL,
  `goal_diff` int(11) NOT NULL,
  `goals_against` int(11) NOT NULL,
  `goals_for` int(11) NOT NULL,
  `lose` int(11) NOT NULL,
  `played` int(11) NOT NULL,
  `points` int(11) NOT NULL,
  `rank` int(11) NOT NULL,
  `win` int(11) NOT NULL,
  `season_league_team_id` bigint(20) NOT NULL,
  `groups` varchar(100) COLLATE utf8mb4_bin DEFAULT NULL,
  PRIMARY KEY (`standings_id`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.team definition

CREATE TABLE `team` (
  `team_id` bigint(20) NOT NULL,
  `created_time` datetime(6) NOT NULL,
  `updated_time` datetime(6) NOT NULL,
  `logo` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `name_eng` varchar(200) COLLATE utf8mb4_bin NOT NULL,
  `name_kr` varchar(100) COLLATE utf8mb4_bin NOT NULL,
  PRIMARY KEY (`team_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;



-- s10p12a802.vote definition

CREATE TABLE `vote` (
  `vote_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `created_time` datetime(6) NOT NULL,
  `is_deleted` tinyint(4) DEFAULT 0,
  `updated_time` datetime(6) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_bin NOT NULL,
  `party_id` bigint(20) NOT NULL,
  PRIMARY KEY (`vote_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;




