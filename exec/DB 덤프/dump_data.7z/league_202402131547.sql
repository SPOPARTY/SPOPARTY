INSERT INTO s10p12a802.league (league_id,created_time,updated_time,country,country_logo,logo,name_eng,name_kr,`type`) VALUES
	 (78,'2024-02-06 21:04:38.400285','2024-02-13 12:00:05.502917','Germany','https://media.api-sports.io/flags/de.svg','https://media.api-sports.io/football/leagues/78.png','Bundesliga','Bundesliga','League'),
	 (140,'2024-02-07 13:31:51.000000','2024-02-13 12:00:05.492786','Spain','https://media.api-sports.io/flags/es.svg','https://media.api-sports.io/football/leagues/140.png','La Liga','La Liga','League'),
	 (292,'2024-02-06 21:04:33.907750','2024-02-13 12:00:05.503096','South-Korea','https://media.api-sports.io/flags/kr.svg','https://media.api-sports.io/football/leagues/292.png','K League 1','K League 1','League');
