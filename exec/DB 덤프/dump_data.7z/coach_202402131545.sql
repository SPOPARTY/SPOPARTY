INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (3,'2024-02-10 22:17:52.743028','2024-02-10 22:17:52.743028',70,'M. Pellegrini','M. Pellegrini','Chile','https://media.api-sports.io/football/coachs/3.png'),
	 (40,'2024-02-10 22:17:59.234744','2024-02-10 22:17:59.234744',50,'T. Tuchel','T. Tuchel','Germany','https://media.api-sports.io/football/coachs/40.png'),
	 (45,'2024-02-10 22:17:52.304558','2024-02-10 22:17:52.304558',51,'Luis García','Luis García','Spain','https://media.api-sports.io/football/coachs/45.png'),
	 (67,'2024-02-10 22:17:51.396239','2024-02-10 22:17:51.396239',63,'Rafael Benítez','Rafael Benítez','Spain','https://media.api-sports.io/football/coachs/67.png'),
	 (82,'2024-02-10 22:17:53.638238','2024-02-10 22:17:53.638238',48,'Míchel','Míchel','Spain','https://media.api-sports.io/football/coachs/82.png'),
	 (339,'2024-02-10 22:17:58.502742','2024-02-10 22:17:58.502742',65,'J. Aguirre','J. Aguirre','Mexico','https://media.api-sports.io/football/coachs/339.png'),
	 (934,'2024-02-10 22:18:07.963543','2024-02-10 22:18:07.963543',50,'Yoon Jung-Hwan','Yoon Jung-Hwan','Korea Republic','https://media.api-sports.io/football/coachs/934.png'),
	 (993,'2024-02-10 22:17:50.937044','2024-02-10 22:17:50.937044',48,'D. Alonso','D. Alonso','Uruguay','https://media.api-sports.io/football/coachs/993.png'),
	 (1335,'2024-02-10 22:18:05.890876','2024-02-10 22:18:05.890876',49,'F. Schmidt','F. Schmidt','Germany','https://media.api-sports.io/football/coachs/1335.png'),
	 (1348,'2024-02-10 22:18:00.695028','2024-02-10 22:18:00.695028',35,'O. Werner','O. Werner','Germany','https://media.api-sports.io/football/coachs/1348.png');
INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (1399,'2024-02-10 22:18:04.537798','2024-02-10 22:18:04.537798',41,'S. Hoeneb','S. Hoeneb','Germany','https://media.api-sports.io/football/coachs/1399.png'),
	 (1402,'2024-02-10 22:18:06.332635','2024-02-10 22:18:06.332635',50,'T. Lieberknecht','T. Lieberknecht','Germany','https://media.api-sports.io/football/coachs/1402.png'),
	 (1426,'2024-02-10 22:18:01.694752','2024-02-10 22:18:01.694752',44,'B. Svensson','B. Svensson','Denmark','https://media.api-sports.io/football/coachs/1426.png'),
	 (1522,'2024-02-10 22:18:04.096547','2024-02-10 22:18:04.096547',53,'J. Thorup','J. Thorup','Denmark','https://media.api-sports.io/football/coachs/1522.png'),
	 (1528,'2024-02-10 22:18:00.244432','2024-02-10 22:18:00.244432',52,'N. Kovač','N. Kovač','Croatia','https://media.api-sports.io/football/coachs/1528.png'),
	 (1533,'2024-02-10 22:18:07.243836','2024-02-10 22:18:07.243836',51,'S. Baumgart','S. Baumgart','Germany','https://media.api-sports.io/football/coachs/1533.png'),
	 (1538,'2024-02-10 22:17:59.683703','2024-02-10 22:17:59.683703',58,'C. Streich','C. Streich','Germany','https://media.api-sports.io/football/coachs/1538.png'),
	 (1540,'2024-02-10 22:18:04.994983','2024-02-10 22:18:04.994983',47,'M. Rose','M. Rose','Germany','https://media.api-sports.io/football/coachs/1540.png'),
	 (1544,'2024-02-10 22:18:06.766467','2024-02-10 22:18:06.766467',57,'U. Fischer','U. Fischer','Switzerland','https://media.api-sports.io/football/coachs/1544.png'),
	 (1549,'2024-02-10 22:18:03.652556','2024-02-10 22:18:03.652556',43,'D. Toppmöller','D. Toppmöller','Germany','https://media.api-sports.io/football/coachs/1549.png');
INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (1581,'2024-02-10 22:17:54.991990','2024-02-10 22:17:54.991990',48,'Gaizka Garitano','Gaizka Garitano','Spain','https://media.api-sports.io/football/coachs/1581.png'),
	 (1582,'2024-02-10 22:17:49.032110','2024-02-10 22:17:49.032110',59,'Ernesto Valverde','Ernesto Valverde','Spain','https://media.api-sports.io/football/coachs/1582.png'),
	 (1586,'2024-02-10 22:17:54.081915','2024-02-10 22:17:54.081915',52,'Imanol Alguacil','Imanol Alguacil','Spain','https://media.api-sports.io/football/coachs/1586.png'),
	 (1588,'2024-02-10 22:17:56.112945','2024-02-10 22:17:56.112945',45,'Arrasate','Arrasate','Spain','https://media.api-sports.io/football/coachs/1588.png'),
	 (1592,'2024-02-10 22:17:54.532460','2024-02-10 22:17:54.532460',56,'Paco López','Paco López','Spain','https://media.api-sports.io/football/coachs/1592.png'),
	 (1595,'2024-02-10 22:17:48.582316','2024-02-10 22:17:48.582316',53,'D. Simeone','D. Simeone','Argentina','https://media.api-sports.io/football/coachs/1595.png'),
	 (1596,'2024-02-10 22:17:53.191525','2024-02-10 22:17:53.191525',59,'José Bordalás','José Bordalás','Spain','https://media.api-sports.io/football/coachs/1596.png'),
	 (1600,'2024-02-10 22:17:55.448131','2024-02-10 22:17:55.448131',47,'Sergio','Sergio','Spain','https://media.api-sports.io/football/coachs/1600.png'),
	 (1888,'2024-02-10 22:17:48.122746','2024-02-10 22:17:48.122746',43,'Xavi','Xavi','Spain','https://media.api-sports.io/football/coachs/1888.png'),
	 (2017,'2024-02-10 22:18:01.224224','2024-02-10 22:18:01.224224',45,'G. Seoane','G. Seoane','Switzerland','https://media.api-sports.io/football/coachs/2017.png');
INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (2116,'2024-02-10 22:17:49.946897','2024-02-10 22:17:49.946897',55,'Pacheta','Pacheta','Spain','https://media.api-sports.io/football/coachs/2116.png'),
	 (2407,'2024-02-10 22:17:51.868020','2024-02-10 22:17:51.868020',64,'C. Ancelotti','C. Ancelotti','Italy','https://media.api-sports.io/football/coachs/2407.png'),
	 (2774,'2024-02-10 22:18:09.340037','2024-02-10 22:18:09.340037',46,'Park Jin-Seop','Park Jin-Seop','Korea Republic','https://media.api-sports.io/football/coachs/2774.png'),
	 (2780,'2024-02-10 22:18:08.888453','2024-02-10 22:18:08.888453',46,'Park Cheol','Park Cheol','Korea Republic','https://media.api-sports.io/football/coachs/2780.png'),
	 (2783,'2024-02-10 22:18:11.590369','2024-02-10 22:18:11.590369',53,'Cho Sung-Hwan','Cho Sung-Hwan','Korea Republic','https://media.api-sports.io/football/coachs/2783.png'),
	 (2790,'2024-02-10 22:18:12.045845','2024-02-10 22:18:12.045845',58,'Choi Soon-Ho','Choi Soon-Ho','Korea Republic','https://media.api-sports.io/football/coachs/2790.png'),
	 (2792,'2024-02-10 22:18:10.703131','2024-02-10 22:18:10.703131',49,'Nam Ki-Il','Nam Ki-Il','Korea Republic','https://media.api-sports.io/football/coachs/2792.png'),
	 (2922,'2024-02-10 22:17:50.400603','2024-02-10 22:17:50.400603',66,'Paco Herrera','Paco Herrera','Spain','https://media.api-sports.io/football/coachs/2922.png'),
	 (2935,'2024-02-10 22:18:05.447175','2024-02-10 22:18:05.447175',55,'T. Letsch','T. Letsch','Germany','https://media.api-sports.io/football/coachs/2935.png'),
	 (3231,'2024-02-10 22:17:57.609507','2024-02-10 22:17:57.609507',45,'Francisco','Francisco','Spain','https://media.api-sports.io/football/coachs/3231.png');
INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (3234,'2024-02-10 22:17:49.491833','2024-02-10 22:17:49.491833',48,'Rubén Baraja','Rubén Baraja','Spain','https://media.api-sports.io/football/coachs/3234.png'),
	 (4202,'2024-02-10 22:18:12.930179','2024-02-10 22:18:12.930179',43,'Lee Eul-Yong','Lee Eul-Yong','Korea Republic','https://media.api-sports.io/football/coachs/4202.png'),
	 (4207,'2024-02-10 22:18:13.768712','2024-02-10 22:18:13.768712',57,'Ko Jeong-Woon','Ko Jeong-Woon','Korea Republic','https://media.api-sports.io/football/coachs/4207.png'),
	 (6801,'2024-02-10 22:18:03.205399','2024-02-10 22:18:03.205399',42,'Xabi Alonso','Xabi Alonso','Spain','https://media.api-sports.io/football/coachs/6801.png'),
	 (7611,'2024-02-10 22:18:02.612888','2024-02-10 22:18:02.612888',46,'P. Matarazzo','P. Matarazzo','USA','https://media.api-sports.io/football/coachs/7611.png'),
	 (9848,'2024-02-10 22:18:09.774170','2024-02-10 22:18:09.774170',46,'Kim Do-Kyun','Kim Do-Kyun','Korea Republic','https://media.api-sports.io/football/coachs/9848.png'),
	 (13491,'2024-02-10 22:18:02.154386','2024-02-10 22:18:02.154386',41,'E. Terzić','E. Terzić','Germany','https://media.api-sports.io/football/coachs/13491.png'),
	 (16725,'2024-02-10 22:18:10.225797','2024-02-10 22:18:10.225797',48,'Lee Jung-Hyo','Lee Jung-Hyo','Korea Republic','https://media.api-sports.io/football/coachs/16725.png'),
	 (18024,'2024-02-10 22:18:08.444937','2024-02-10 22:18:08.444937',42,'Choi Won-Kwon','Choi Won-Kwon','Korea Republic','https://media.api-sports.io/football/coachs/18024.png'),
	 (19988,'2024-02-10 22:18:11.150361','2024-02-10 22:18:11.150361',41,'Kim Do-Heon','Kim Do-Heon','Korea Republic','https://media.api-sports.io/football/coachs/19988.png');
INSERT INTO s10p12a802.coach (coach_id,created_time,updated_time,age,name_eng,name_kr,nationality,photo) VALUES
	 (21103,'2024-02-10 22:18:12.482698','2024-02-10 22:18:12.482698',40,'Yeom Ki-Hun','Yeom Ki-Hun','Korea Republic','https://media.api-sports.io/football/coachs/21103.png');
