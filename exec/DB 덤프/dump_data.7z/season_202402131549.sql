INSERT INTO s10p12a802.season (created_time,updated_time,value) VALUES
	 ('2024-02-06 22:22:59.586915','2024-02-13 12:00:05.497474','2023');
